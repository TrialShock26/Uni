#ifndef MYTEST_HPP
#define MYTEST_HPP

void mytest();

#endif